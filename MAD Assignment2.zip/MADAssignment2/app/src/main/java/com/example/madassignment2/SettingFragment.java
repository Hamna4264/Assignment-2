package com.example.madassignment2;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class SettingFragment extends Fragment {

    private EditText usernameField, emailField, passwordField;
    private Button saveButton;
    private SharedPreferences preferences;

    private static final String PREF_NAME = "UserPreferences";

    @Override
    public View onCreateView( LayoutInflater inflater, ViewGroup container,  Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_settingfragment, container, false);

        usernameField = view.findViewById(R.id.username_field);
        emailField = view.findViewById(R.id.email_field);
        passwordField = view.findViewById(R.id.password_field);
        saveButton = view.findViewById(R.id.save_button);

        preferences = requireActivity().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);

        saveButton.setOnClickListener(v -> savePreferences());

        return view;
    }

    private void savePreferences() {
        String username = usernameField.getText().toString().trim();
        String email = emailField.getText().toString().trim();
        String password = passwordField.getText().toString().trim();

        if (username.isEmpty() || email.isEmpty() || password.isEmpty()) {
            Toast.makeText(getActivity(), "Please fill all fields.", Toast.LENGTH_SHORT).show();
            return;
        }

        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("username", username);
        editor.putString("email", email);
        editor.putString("password", password);
        editor.apply();

        Toast.makeText(getActivity(), "Preferences saved successfully.", Toast.LENGTH_SHORT).show();
    }
}

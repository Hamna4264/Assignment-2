package com.example.madassignment2;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ProfileFragment extends Fragment {

    private TextView usernameView, emailView, passwordView;

    @Override
    public View onCreateView( LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profilefragment, container, false);

        usernameView = view.findViewById(R.id.profile_username);
        emailView = view.findViewById(R.id.profile_email);
        passwordView = view.findViewById(R.id.profile_password);

        loadProfileData(view.getContext());

        return view;
    }

    private void loadProfileData(Context context) {
        SharedPreferences preferences = context.getSharedPreferences("UserPreferences", Context.MODE_PRIVATE);

        usernameView.setText("Username: " + preferences.getString("username", "N/A"));
        emailView.setText("Email: " + preferences.getString("email", "N/A"));
        passwordView.setText("Password: " + preferences.getString("password", "N/A"));
    }
}
